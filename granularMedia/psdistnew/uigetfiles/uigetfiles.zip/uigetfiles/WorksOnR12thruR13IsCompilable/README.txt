This version of uigetfiles.dll will run on MATLAB 6.0 (R12) through 6.5 (R13) for Windows 
at least.  It may work on future versions as well.  This version can also be compiled into 
a standalone application.  A version that will run on MATLAB 5.2 (R10) through 6.5 (R13)
for Windows is also available in this ZIP archive.

This was created using the source, and compiled using the following command:
mex uigetfiles.cpp <path to COMDLG32.LIB>

2/26/2003