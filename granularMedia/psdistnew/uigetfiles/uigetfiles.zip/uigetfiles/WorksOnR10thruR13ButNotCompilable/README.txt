This version of uigetfiles.dll will run on MATLAB 5.2 (R10) through 6.5 (R13) for Windows 
at least.  It may work on future versions as well.  However, it cannot be compiled into a 
standalone application.  That version is also available inside this ZIP archive.

2/26/2003